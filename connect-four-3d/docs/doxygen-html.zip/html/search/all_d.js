var searchData=
[
  ['receivecoup_96',['receiveCoup',['../classarbitre.html#a1ff9acf4f5a4514b2cd4a9816d50619b',1,'arbitre::receiveCoup()'],['../classjoueur.html#a9f6ae5901d4dfe5d4d58ddf88473b835',1,'joueur::receiveCoup()']]]
];

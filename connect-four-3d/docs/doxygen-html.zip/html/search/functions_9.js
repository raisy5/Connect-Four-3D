var searchData=
[
  ['nbmasques_219',['nbMasques',['../classBitBoard.html#acdaa5f85ccc3ae80f04037dd36376649',1,'BitBoard']]],
  ['numposition_220',['NumPosition',['../classposition.html#ada25cc61e10661b69725026d6d4e8774',1,'position']]]
];

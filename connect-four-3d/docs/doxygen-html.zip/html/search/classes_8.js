var searchData=
[
  ['strategy_144',['Strategy',['../classStrategy.html',1,'']]]
];

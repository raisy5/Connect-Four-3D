var searchData=
[
  ['placerperle_225',['placerPerle',['../classBoard.html#a8d3251afb47381bf8a1a3a5cba5c1274',1,'Board']]],
  ['plateauplein_226',['plateauPlein',['../classBitBoard.html#a4752d16942c2381687458da5a465bbbc',1,'BitBoard']]],
  ['player_227',['Player',['../classPlayer.html#aaed8b701c0495f616010e78fc9475c5a',1,'Player::Player(Couleur c, const std::string &amp;n)'],['../classPlayer.html#a4a8b7f689e924b15a9e6f9888983fb43',1,'Player::Player(const Player &amp;other)']]],
  ['poser_228',['poser',['../classBitBoard.html#a0ea294b42f5e7387432683a4d963bc27',1,'BitBoard']]],
  ['position_229',['position',['../classposition.html#ae6057e234a5756f9ef372bdf94b27262',1,'position::position(char h=&apos;A&apos;, int v=0, int l=0)'],['../classposition.html#ac015704fc72be6d11f482daffefbc060',1,'position::position(const position &amp;o)']]],
  ['positionnummpi_230',['positionNumMPI',['../classposition.html#a7d91ad064232b0ae11042d8954da033f',1,'position']]]
];

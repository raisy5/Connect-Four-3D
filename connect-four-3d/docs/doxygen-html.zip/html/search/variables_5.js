var searchData=
[
  ['n_259',['n',['../classposition.html#acd11fd2fb6645138c7129be36d83803b',1,'position']]],
  ['nom_260',['nom',['../classPlayer.html#a61e93204ac197b33775b17bc784957fd',1,'Player']]]
];

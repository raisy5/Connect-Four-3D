var searchData=
[
  ['indice_212',['indice',['../classBitBoard.html#a31b0933dc843a9d31da3876a11c6b075',1,'BitBoard']]]
];

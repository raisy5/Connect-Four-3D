var searchData=
[
  ['score_262',['score',['../structEntreeTransposition.html#aa4879f4ccf91df2d410a49dfa8cd9ee8',1,'EntreeTransposition']]]
];

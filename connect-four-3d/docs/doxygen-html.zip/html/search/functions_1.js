var searchData=
[
  ['bitboard_180',['BitBoard',['../classBitBoard.html#a16e5151e747beb21473ab790d60e4e36',1,'BitBoard::BitBoard()'],['../classBitBoard.html#a3643a4e9da092e7c689ffe660751dcfa',1,'BitBoard::BitBoard(const BitBoard &amp;other)']]],
  ['board_181',['Board',['../classBoard.html#a9ee491d4fea680cf69b033374a9fdfcb',1,'Board::Board()'],['../classBoard.html#af23f785e7c9d49271672c79c09cfa4e6',1,'Board::Board(const Board &amp;other)']]]
];

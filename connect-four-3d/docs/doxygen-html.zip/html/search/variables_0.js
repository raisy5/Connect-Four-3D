var searchData=
[
  ['alpha_254',['alpha',['../classposition.html#aa8c6e8a3a09f4d78dc971e9ef52792dd',1,'position']]]
];

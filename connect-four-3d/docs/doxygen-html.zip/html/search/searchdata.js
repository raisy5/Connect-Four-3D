var indexSectionsWithContent =
{
  0: "abceghijlmnoprstuv~",
  1: "abcegjmps",
  2: "abcegjmpst",
  3: "abcegijlmnoprsv~",
  4: "achlmnpstv",
  5: "u",
  6: "ct",
  7: "belnuv",
  8: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type",
  6: "Énumérations",
  7: "Valeurs énumérées",
  8: "Amis"
};


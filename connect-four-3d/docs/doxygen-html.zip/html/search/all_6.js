var searchData=
[
  ['indice_61',['indice',['../classBitBoard.html#a31b0933dc843a9d31da3876a11c6b075',1,'BitBoard']]]
];
